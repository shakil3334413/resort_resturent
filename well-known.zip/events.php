    <?php 
        include 'inc/header.php';
        include 'inc/menubar.php';
        include 'inc/mobile-menu.php'; 
    ?>
	<!-- nav.mobile-menu-container -->

    <!-- Main Content -->
    <div id="main-content">
        <div class="page-title">
            <div class="page-title-wrapper" data-stellar-background-ratio="0.5">
                <div class="content container">
                    <h1 class="heading_primary">Events</h1>
                    <ul class="breadcrumbs">
                        <li class="item"><a href="index.php">Home</a></li>
                        <li class="item"><span class="separator"></span></li>
                        <li class="item active">Event List View</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="site-content container">
            <div class="events-content">
                <div class="sc-events list-style">
                    <nav class="filter-events">
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="happening-tab" data-toggle="tab" href="#happening" role="tab" aria-selected="true">happening</a>
                            <a class="nav-item nav-link" id="nav-upcoming-tab" data-toggle="tab" href="#upcoming" role="tab" aria-selected="false">upcoming</a>
                            <a class="nav-item nav-link" id="nav-expired-tab" data-toggle="tab" href="#expired" role="tab"  aria-selected="false">expired</a>
                        </div>
                    </nav>
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="happening" role="tabpanel">
                            <div class="event">
                                <div class="row tm-flex">
                                <div class="col-lg-2 col-md-2">
                                    <div class="time-from">
                                        <span class="date">15</span>
                                        <span class="month">July</span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-5">
                                    <div class="event-content">
                                        <h3 class="title"><a href="event-single.php">Wedding John & Ina</a></h3>
                                        <div class="meta">
                                            <span class="time"> <i class="fa fa-clock-o"></i> 8:00 am - 5:00 pm</span>
                                            <span class="location"> <i class="fa fa-map-marker"></i>PARIS, FRENCH</span>
                                        </div>
                                        <div class="event-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-5">
                                    <div class="thumbnail">
                                        <a href="event-single.php"><img src="images/gallery/img-13.jpg" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <div class="event">
                                <div class="row tm-flex">
                                    <div class="col-lg-2 col-md-2">
                                        <div class="time-from">
                                            <span class="date">20</span>
                                            <span class="month">July</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-5">
                                        <div class="event-content">
                                            <h3 class="title"><a href="event-single.php">BBQ and Beer</a></h3>
                                            <div class="meta">
                                                <span class="time"> <i class="fa fa-clock-o"></i> 8:00 pm - 4:00 am</span>
                                                <span class="location"> <i class="fa fa-map-marker"></i>PARIS, FRENCH</span>
                                            </div>
                                            <div class="event-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5">
                                        <div class="thumbnail">
                                            <a href="event-single.php"><img src="images/gallery/img-2.jpg" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="event">
                                <div class="row tm-flex">
                                    <div class="col-lg-2 col-md-2">
                                        <div class="time-from">
                                            <span class="date">25</span>
                                            <span class="month">July</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-5">
                                        <div class="event-content">
                                            <h3 class="title"><a href="event-single.php">Pool Party</a></h3>
                                            <div class="meta">
                                                <span class="time"> <i class="fa fa-clock-o"></i> 10:00 am - 3:00 pm</span>
                                                <span class="location"> <i class="fa fa-map-marker"></i>PARIS, FRENCH</span>
                                            </div>
                                            <div class="event-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5">
                                        <div class="thumbnail">
                                            <a href="event-single.php"><img src="images/gallery/img-12.jpg" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="upcoming" role="tabpanel" aria-labelledby="nav-upcoming-tab">
                            <div class="event">
                                <div class="row tm-flex">
                                    <div class="col-lg-2 col-md-2">
                                        <div class="time-from">
                                            <span class="date">23</span>
                                            <span class="month">July</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-5">
                                        <div class="event-content">
                                            <h3 class="title"><a href="event-single.php">Hotel Summer 2019</a></h3>
                                            <div class="meta">
                                                <span class="time"> <i class="fa fa-clock-o"></i> 8:00 am - 5:00 pm</span>
                                                <span class="location"> <i class="fa fa-map-marker"></i>PARIS, FRENCH</span>
                                            </div>
                                            <div class="event-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5">
                                        <div class="thumbnail">
                                            <a href="event-single.php"><img src="images/gallery/img-8.jpg" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="event">
                                <div class="row tm-flex">
                                    <div class="col-lg-2 col-md-2">
                                        <div class="time-from">
                                            <span class="date">25</span>
                                            <span class="month">July</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-5">
                                        <div class="event-content">
                                            <h3 class="title"><a href="event-single.php">Hotel Autumn 2019</a></h3>
                                            <div class="meta">
                                                <span class="time"> <i class="fa fa-clock-o"></i> 8:00 pm - 4:00 am</span>
                                                <span class="location"> <i class="fa fa-map-marker"></i>PARIS, FRENCH</span>
                                            </div>
                                            <div class="event-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5">
                                        <div class="thumbnail">
                                            <a href="event-single.php"><img src="images/gallery/img-5.jpg" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="event">
                                <div class="row tm-flex">
                                    <div class="col-lg-2 col-md-2">
                                        <div class="time-from">
                                            <span class="date">28</span>
                                            <span class="month">July</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-5">
                                        <div class="event-content">
                                            <h3 class="title"><a href="event-single.php">Pool Party</a></h3>
                                            <div class="meta">
                                                <span class="time"> <i class="fa fa-clock-o"></i> 10:00 am - 3:00 pm</span>
                                                <span class="location"> <i class="fa fa-map-marker"></i>PARIS, FRENCH</span>
                                            </div>
                                            <div class="event-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5">
                                        <div class="thumbnail">
                                            <a href="event-single.php"><img src="images/gallery/img-10.jpg" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="expired" role="tabpanel" aria-labelledby="nav-expired-tab">
                            <div class="event">
                                <div class="row tm-flex">
                                    <div class="col-lg-2 col-md-2">
                                        <div class="time-from">
                                            <span class="date">10</span>
                                            <span class="month">July</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-5">
                                        <div class="event-content">
                                            <h3 class="title"><a href="event-single-expired.php">Hotel Family Party</a></h3>
                                            <div class="meta">
                                                <span class="time"> <i class="fa fa-clock-o"></i> 8:00 am - 5:00 pm</span>
                                                <span class="location"> <i class="fa fa-map-marker"></i>PARIS, FRENCH</span>
                                            </div>
                                            <div class="event-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5">
                                        <div class="thumbnail">
                                            <a href="event-single-expired.php"><img src="images/gallery/img-6.jpg" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="event">
                                <div class="row tm-flex">
                                    <div class="col-lg-2 col-md-2">
                                        <div class="time-from">
                                            <span class="date">15</span>
                                            <span class="month">July</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-5">
                                        <div class="event-content">
                                            <h3 class="title"><a href="event-single-expired.php">Birthday Party</a></h3>
                                            <div class="meta">
                                                <span class="time"> <i class="fa fa-clock-o"></i> 8:00 pm - 4:00 am</span>
                                                <span class="location"> <i class="fa fa-map-marker"></i>PARIS, FRENCH</span>
                                            </div>
                                            <div class="event-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5">
                                        <div class="thumbnail">
                                            <a href="event-single-expired.php"><img src="images/gallery/img-4.jpg" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="event">
                                <div class="row tm-flex">
                                    <div class="col-lg-2 col-md-1">
                                        <div class="time-from">
                                            <span class="date">22</span>
                                            <span class="month">July</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                        <div class="event-content">
                                            <h3 class="title"><a href="event-single-expired.php">Pool Party</a></h3>
                                            <div class="meta">
                                                <span class="time"> <i class="fa fa-clock-o"></i> 10:00 am - 3:00 pm</span>
                                                <span class="location"> <i class="fa fa-map-marker"></i>PARIS, FRENCH</span>
                                            </div>
                                            <div class="event-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5">
                                        <div class="thumbnail">
                                            <a href="event-single-expired.php"><img src="images/gallery/img-12.jpg" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php include 'inc/footer.php'; ?>