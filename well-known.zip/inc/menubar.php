    <!-- Header -->
    <header id="masthead" class="header-overlay affix-top sticky-header header_v2">
	        <div class="container">
            <div class="row">
                <div class="header-menu col-sm-12 tm-table">
                    <div class="menu-mobile-effect navbar-toggle" data-effect="mobile-effect">
                        <div class="icon-wrap">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </div>
                    </div>

                    <div class="width-logo sm-logo table-cell">
                        <a href="index.php" class="no-sticky-logo">
                            <img class="logo" src="images/logo.png" alt="">
                            <img class="mobile-logo" src="images/logo.png" alt="">
                        </a>
                        <a href="index.php" class="sticky-logo">
                            <img src="images/logo.png" alt="">
                        </a>
                    </div>
                    <div class="width-navigation navigation table-cell">
                        <ul class="nav main-menu">
                            <li class="menu-item has-children">
							<li class="menu-item"><a href="index.php">Home</a></li>
							<li class="menu-item"><a href="about.php">About</a></li>
                            <li class="menu-item has-children">
                                <a href="rooms.php">Rooms</a>
                                <ul class="sub-menu">
									<li class="menu-item"><a href="single.php">A/C Single Deluxe</a></li>
                                    <li class="menu-item"><a href="double.php">A/C Double Deluxe</a></li>
                                    <li class="menu-item"><a href="deluxe.php">A/C Deluxe Suite</a></li>
									<li class="menu-item"><a href="family.php">A/C Eque Family Suite</a></li>
                                    <li class="menu-item"><a href="officer.php">Juniour Officer's Room</a></li>
                                </ul>
                            </li>
							<li class="menu-item"><a href="gallery.php">Gallery</a></li>
							<!--
                            <li class="menu-item has-children">
                                <a href="blog.php">Blog</a>
                                <ul class="sub-menu">
                                    <li class="menu-item"><a href="blog-sidebar-left.php">Blog Sidebar Left</a></li>
                                    <li class="menu-item"><a href="blog-sidebar-right.php">Blog Sidebar Right</a></li>
                                    <li class="menu-item"><a href="blog-no-sidebar.php">Blog Without Sidebar</a></li>
                                    <li class="menu-item"><a href="blog-single.php">Single Post</a></li>
                                    <li class="menu-item"><a href="blog-single-gallery.php">Single Post Gallery</a></li>
                                </ul>
                            </li>
							-->
							<li class="menu-item"><a href="package.php">Packages</a></li>
							<li class="menu-item"><a href="events.php">Events</a></li>
							<li class="menu-item"><a href="contact.php">Contact</a></li>
                        </ul>
                        <div class="header-right">
                            <div class="phone">
                                <a href="tel:00123456789" class="value"><i class="fa fa-phone"></i> +88 01317121871</a>
                            </div>
                            <div class="book-button">
                                <a href="rooms.php" class="btn-book">BOOK NOW</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    
