    <footer id="colophon" class="site-footer">
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="widget-text">
                            <div class="footer-location">
                                <img src="images/logo1-footer.png" alt="">
                                <p>You have questions regarding our services? Contact us, we will be happy to help you out!</p>
                                <ul class="info">
                                    <li><i class="ion-ios-location"></i> <span>123 Camino Ramon, Suite 500 San Ramon, United Kingdom</span></li>
                                    <li><i class="ion-ios-telephone"></i><a href="tel:8812345678">(+88) 12-345-678</a></li>
                                    <li><i class="ion-email"></i><a href="mailto:contact@thimpress.com">contact@thimpress.com</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="widget-menu">
                            <h3 class="widget-title">Booking</h3>
                            <ul class="menu">
                                <li><a href="#">Rooms & Suites</a></li>
                                <li><a href="#">Restaurant</a></li>
                                <li><a href="#">Spa & Fitness</a></li>
                                <li><a href="#">Shop</a></li>
                                <li><a href="#">Gallery</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="widget-menu">
                            <h3 class="widget-title">About Us</h3>
                            <ul class="menu">
                                <li><a href="#">Our Story</a></li>
                                <li><a href="#">Blog & Events</a></li>
                                <li><a href="#">Awards</a></li>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="widget-menu">
                            <h3 class="widget-title">Connect Us</h3>
                            <ul class="list-social">
                                <li><a class="facebook" href="https://www.facebook.com/thimpress">Facebook</a></li>
                                <li><a class="twitter" href="https://www.twitter.com/thimpress">Twitter</a></li>
                                <li><a class="instagram" href="http://www.thimpress.com/">Instagram</a></li>
                                <li><a class="youtube" href="http://www.thimpress.com/">Youtube</a></li>
                                <li><a class="google" href="http://www.thimpress.com/">Google +</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="copyright-content col-sm-6">
                        <p class="copyright-text tx-1">© 2020 <a href="http://www.equeheritageresort.com/">Eque Heritage Hotel and Resort</a>. All Rights Reserved.</p>
                    </div>
                    <div class="copyright-content col-sm-6">
                        <p class="copyright-text tx-2">Designed & Developed by <a href="https://ekattorit.com/"> EKATTOR iT</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div><!-- wrapper-container -->

<div id="back-to-top">
    <i class="ion-ios-arrow-up" aria-hidden="true"></i>
</div>


<!-- Scripts -->
<script src="js/libs/jquery-1.12.4.min.js"></script><!-- jQuery -->
<script src="js/libs/bootstrap.min.js"></script><!-- Bootstrap -->
<script src="js/libs/smoothscroll.min.js"></script><!-- smoothscroll -->
<script src="js/libs/owl.carousel.min.js"></script><!-- Owl Carousel -->
<script src="js/libs/jquery.magnific-popup.min.js"></script><!-- Magnific Popup -->
<script src="js/libs/theia-sticky-sidebar.min.js"></script><!-- Sticky sidebar -->
<script src="js/libs/stellar.min.js"></script><!-- counter -->
<script src="js/libs/counter-box.min.js"></script><!-- counter -->
<script src="js/libs/isotope.pkgd.min.js"></script><!-- Sticky sidebar -->
<script src="js/libs/jquery.thim-content-slider.min.js"></script><!-- Slider -->
<script src="js/libs/moment.min.js"></script><!-- moment -->
<script src="js/libs/jquery-ui.min.js"></script><!-- ui -->
<script src="js/libs/daterangepicker.min.js"></script><!-- date -->
<script src="js/libs/daterangepicker.min-date.min.js"></script><!-- date2 -->
<script src="js/theme-customs.js"></script><!-- Theme Custom -->
<script src="js/libs/jquery.flexslider-min.js"></script><!-- flexslider -->
<script src="js/libs/gallery.min.js"></script><!-- gallery -->

<?php 
    if ($fm->title() == "Contact") {
        echo "
        <script async defer src='https://maps.googleapis.com/maps/api/js?key=AIzaSyCEv6YBbPEv4wCR-AkQ5dmQ4GXXGa_6vIc&amp;callback=sc_Map></script>
        <script src='js/google-map.js'></script> <!-- Google Map -->
        ";
    }

?>

<!-- REVOLUTION JS FILES -->
<script  src="js/libs/revolution/jquery.themepunch.tools.min.js"></script>
<script src="js/libs/revolution/jquery.themepunch.revolution.min.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script src="js/libs/revolution/extensions/revolution.extension.actions.min.js"></script>
<script src="js/libs/revolution/extensions/revolution.extension.carousel.min.js"></script>
<script src="js/libs/revolution/extensions/revolution.extension.kenburn.min.js"></script>
<script src="js/libs/revolution/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="js/libs/revolution/extensions/revolution.extension.migration.min.js"></script>
<script src="js/libs/revolution/extensions/revolution.extension.navigation.min.js"></script>
<script src="js/libs/revolution/extensions/revolution.extension.parallax.min.js"></script>
<script src="js/libs/revolution/extensions/revolution.extension.slideanims.min.js"></script>
<script src="js/libs/revolution/extensions/revolution.extension.video.min.js"></script>

<?php 
    if ($fm->title() == "Event Single") {
        echo "<script src='js/libs/jquery.mb-comingsoon.min.js'></script><!-- coming soon -->";
        echo "
        $('.thim-countdown .count-down').mbComingsoon({
        expiryDate: new Date($('.thim-countdown').data('date')),
        speed     : 100
        });
        ";
    } elseif ($fm->title() == "Event Single Expired") {
        echo "<script src='js/thim-countdown.js'></script>";
    } elseif ($fm->title() == "Eque's Heritage Hotel & Resort") {
        echo "<script src='js/wrapping.js'></script>";
    } else {
        
    }

 ?>

</body>

</html>