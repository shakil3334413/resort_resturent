<?php
    include 'lib/Database.php';
    include 'helpers/Format.php';
    $db  = new Database();
    $fm  = new Format();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $fm->title() ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Favicons -->
    <link rel="shortcut icon" href="images/icons/favicon.png">
    <link rel="stylesheet" href="css/libs/jquery-ui/jquery-ui.min.css">
    <!-- REVOLUTION STYLE SHEETS -->
    
    <link rel="stylesheet" href="css/style.css"><!-- Style -->
    
    <!-- REVOLUTION STYLE SHEETS -->
    <link rel="stylesheet" type="text/css" href="css/libs/revolution/settings.css">
</head>
<body class="demo-3 home room single">

<div id="preloading" class="color2">
    <div class="loading-icon">
        <div class="sk-folding-cube">
            <div class="sk-cube1 sk-cube"></div>
            <div class="sk-cube2 sk-cube"></div>
            <div class="sk-cube4 sk-cube"></div>
            <div class="sk-cube3 sk-cube"></div>
        </div>
    </div>
</div>

<!-- Wrapper content -->
<div id="wrapper-container" class="content-pusher">
    <div class="overlay-close-menu"></div>

