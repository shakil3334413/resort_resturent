    <?php 
        include 'inc/header.php';
        include 'inc/menubar.php';
        include 'inc/mobile-menu.php'; 
    ?>
    <!-- nav.mobile-menu-container -->

    <!-- Main Content -->
    <div id="main-content">
        <div class="page-title">
            <div class="page-title-wrapper" data-stellar-background-ratio="0.5">
                <div class="content container">
                    <h1 class="heading_primary">Blogs</h1>
                    <ul class="breadcrumbs">
                        <li class="item"><a href="index.php">Home</a></li>
                        <li class="item"><span class="separator"></span></li>
                        <li class="item active">Blogs</li>
                    </ul>
                </div>
            </div>
        </div>

       <div class="site-content container">
           <div class="blog-content layout-grid">
               <div class="row">
                   <article class="post col-sm-4 clearfix">
                       <div class="post-content">
                           <div class="post-media">
                               <a href="blog-single.html"><img src="images/gallery/img-4.jpg" alt=""></a>
                           </div>
                           <div class="post-summary">
                               <h2 class="post-title">
                                   <a href="blog-single.html">Small Living Room</a>
                               </h2>
                               <ul class="post-meta">
                                   <li>by <a href="#">Bobby</a></li>
                                   <li><span class="separator"></span></li>
                                   <li>July 01, 2018</li>
                                   <li><span class="separator"></span></li>
                                   <li><a href="blog-single.html#comments-list">3 Comments</a></li>

                               </ul>
                               <p class="post-description" lang="zxx">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. Suspendisse potenti. Sed nisi ex, tincidunt eu lorem at, molestie ullamcorper ipsum. Vivamus sollicitudin, mauris nec.</p>
                               <a href="blog-single.html" class="btn-icon">Read more</a>
                           </div>
                       </div>
                   </article>
                   <article class="post col-sm-4 clearfix">
                       <div class="post-content">
                           <div class="post-media">
                               <a href="blog-single.html"><img src="images/gallery/img-5.jpg" alt=""></a>
                           </div>
                           <div class="post-summary">
                               <h2 class="post-title">
                                   <a href="blog-single.html">Small Living Room</a>
                               </h2>
                               <ul class="post-meta">
                                   <li>by <a href="#">Bobby</a></li>
                                   <li><span class="separator"></span></li>
                                   <li>July 01, 2018</li>
                                   <li><span class="separator"></span></li>
                                   <li><a href="blog-single.html#comments-list">3 Comments</a></li>

                               </ul>
                               <p class="post-description" lang="zxx">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. Suspendisse potenti. Sed nisi ex, tincidunt eu lorem at, molestie ullamcorper ipsum. Vivamus sollicitudin, mauris nec.</p>
                               <a href="blog-single.html" class="btn-icon">Read more</a>
                           </div>
                       </div>
                   </article>
                   <article class="post col-sm-4 clearfix">
                       <div class="post-content">
                           <div class="post-media">
                               <a href="blog-single.html"><img src="images/gallery/img-3.jpg" alt=""></a>
                           </div>
                           <div class="post-summary">
                               <h2 class="post-title">
                                   <a href="blog-single.html">Small Living Room</a>
                               </h2>
                               <ul class="post-meta">
                                   <li>by <a href="#">Bobby</a></li>
                                   <li><span class="separator"></span></li>
                                   <li>July 01, 2018</li>
                                   <li><span class="separator"></span></li>
                                   <li><a href="blog-single.html#comments-list">3 Comments</a></li>

                               </ul>
                               <p class="post-description" lang="zxx">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. Suspendisse potenti. Sed nisi ex, tincidunt eu lorem at, molestie ullamcorper ipsum. Vivamus sollicitudin, mauris nec.</p>
                               <a href="blog-single.html" class="btn-icon">Read more</a>
                           </div>
                       </div>
                   </article>

                   <article class="post col-sm-4 clearfix">
                       <div class="post-content">
                           <div class="post-media">
                               <a href="blog-single.html"><img src="images/gallery/img-1.jpg" alt=""></a>
                           </div>
                           <div class="post-summary">
                               <h2 class="post-title">
                                   <a href="blog-single.html">Small Living Room</a>
                               </h2>
                               <ul class="post-meta">
                                   <li>by <a href="#">Bobby</a></li>
                                   <li><span class="separator"></span></li>
                                   <li>July 01, 2018</li>
                                   <li><span class="separator"></span></li>
                                   <li><a href="blog-single.html#comments-list">3 Comments</a></li>

                               </ul>
                               <p class="post-description" lang="zxx">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. Suspendisse potenti. Sed nisi ex, tincidunt eu lorem at, molestie ullamcorper ipsum. Vivamus sollicitudin, mauris nec.</p>
                               <a href="blog-single.html" class="btn-icon">Read more</a>
                           </div>
                       </div>
                   </article>
                   <article class="post col-sm-4 clearfix">
                       <div class="post-content">
                           <div class="post-media">
                               <a href="blog-single.html"><img src="images/gallery/img-2.jpg" alt=""></a>
                           </div>
                           <div class="post-summary">
                               <h2 class="post-title">
                                   <a href="blog-single.html">Small Living Room</a>
                               </h2>
                               <ul class="post-meta">
                                   <li>by <a href="#">Bobby</a></li>
                                   <li><span class="separator"></span></li>
                                   <li>July 01, 2018</li>
                                   <li><span class="separator"></span></li>
                                   <li><a href="blog-single.html#comments-list">3 Comments</a></li>

                               </ul>
                               <p class="post-description" lang="zxx">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. Suspendisse potenti. Sed nisi ex, tincidunt eu lorem at, molestie ullamcorper ipsum. Vivamus sollicitudin, mauris nec.</p>
                               <a href="blog-single.html" class="btn-icon">Read more</a>
                           </div>
                       </div>
                   </article>
                   <article class="post col-sm-4 clearfix">
                       <div class="post-content">
                           <div class="post-media">
                               <a href="blog-single.html"><img src="images/gallery/img-8.jpg" alt=""></a>
                           </div>
                           <div class="post-summary">
                               <h2 class="post-title">
                                   <a href="blog-single.html">Small Living Room</a>
                               </h2>
                               <ul class="post-meta">
                                   <li>by <a href="#">Bobby</a></li>
                                   <li><span class="separator"></span></li>
                                   <li>July 01, 2018</li>
                                   <li><span class="separator"></span></li>
                                   <li><a href="blog-single.html#comments-list">3 Comments</a></li>

                               </ul>
                               <p class="post-description" lang="zxx">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis eleifend lorem nec ultricies. Suspendisse potenti. Sed nisi ex, tincidunt eu lorem at, molestie ullamcorper ipsum. Vivamus sollicitudin, mauris nec.</p>
                               <a href="blog-single.html" class="btn-icon">Read more</a>
                           </div>
                       </div>
                   </article>

                   <ul class="loop-pagination">
                       <li><a href="#"><i class="fa fa-angle-left"></i></a></li>
                       <li><a href="#">1</a></li>
                       <li class="active"><a href="#">2</a></li>
                       <li><a href="#">3</a></li>
                       <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
                   </ul>

               </div>
           </div>
       </div>
    </div>
    <!-- Footer -->
    <?php include 'inc/footer.php'; ?>