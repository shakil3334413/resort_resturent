
    <?php 
        include 'inc/header.php';
        include 'inc/menubar.php';
        include 'inc/mobile-menu.php'; 
    ?>
    <!-- Main Content -->
    <div id="main-content">
        <div class="page-title">
            <div class="page-title-wrapper" data-stellar-background-ratio="0.5">
                <div class="content container">
                    <h1 class="heading_primary">Our Rooms</h1>
                    <ul class="breadcrumbs">
                        <li class="item"><a href="index.php">Home</a></li>
                        <li class="item"><span class="separator"></span></li>
                        <li class="item active">Rooms</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="site-content container">
            <div class="rooms-content layout-grid style-02">
                <div class="row">
                    <div class="room col-sm-4 clearfix">
                        <div class="room-item">
                            <div class="room-media">
                                <a href="room-single.php"><img src="images/gallery/img-4.jpg" alt=""></a>
                            </div>
                            <div class="room-summary">
                                <h3 class="room-title">
                                    <a href="room-single.php">A/C Singule Deluxe</a>
                                </h3>
                                <ul class="room-info">
                                    <li>18 m2</li>
                                    <li><span class="separator"></span></li>
                                    <li>Balcony</li>
                                    <li><span class="separator"></span></li>
                                    <li>Lake view</li>
                                </ul>
                                <div class="line"></div>
                                <div class="room-meta clearfix">
                                    <div class="price">
                                        <span class="title-price">From:</span>
                                        <span class="price_value price_min">BDT 2500</span>
                                        <span class="unit">Night</span>
                                    </div>
                                    <div class="rating"><span class="star"></span></div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="room col-sm-4 clearfix">
                        <div class="room-item">
                            <div class="room-media">
                                <a href="room-single.php"><img src="images/gallery/img-11.jpg" alt=""></a>
                            </div>
                            <div class="room-summary">
                                <h3 class="room-title">
                                    <a href="room-single.php">A/C Double Deluxe</a>
                                </h3>
                                <ul class="room-info">
                                    <li>18 m2</li>
                                    <li><span class="separator"></span></li>
                                    <li>Balcony</li>
                                    <li><span class="separator"></span></li>
                                    <li>Lake view</li>
                                </ul>
                                <div class="line"></div>
                                <div class="room-meta clearfix">
                                    <div class="price">
                                        <span class="title-price">From:</span>
                                        <span class="price_value price_min">BDT 3500</span>
                                        <span class="unit">Night</span>
                                    </div>
                                    <div class="rating"><span class="star"></span></div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="room col-sm-4 clearfix">
                        <div class="room-item">
                            <div class="room-media">
                                <a href="room-single.php"><img src="images/gallery/img-6.jpg" alt=""></a>
                            </div>
                            <div class="room-summary">
                                <h3 class="room-title">
                                    <a href="room-single.php">A/C Deluxe Suite</a>
                                </h3>
                                <ul class="room-info">
                                    <li>18 m2</li>
                                    <li><span class="separator"></span></li>
                                    <li>Balcony</li>
                                    <li><span class="separator"></span></li>
                                    <li>Lake view</li>
                                </ul>
                                <div class="line"></div>
                                <div class="room-meta clearfix">
                                    <div class="price">
                                        <span class="title-price">From:</span>
                                        <span class="price_value price_min">BDT 4500</span>
                                        <span class="unit">Night</span>
                                    </div>
                                    <div class="rating"><span class="star"></span></div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="room col-sm-4 clearfix">
                        <div class="room-item">
                            <div class="room-media">
                                <a href="room-single.php"><img src="images/gallery/img-10.jpg" alt=""></a>
                            </div>
                            <div class="room-summary">
                                <h3 class="room-title">
                                    <a href="room-single.php">A/C Eque Family Suite</a>
                                </h3>
                                <ul class="room-info">
                                    <li>18 m2</li>
                                    <li><span class="separator"></span></li>
                                    <li>Balcony</li>
                                    <li><span class="separator"></span></li>
                                    <li>Lake view</li>
                                </ul>
                                <div class="line"></div>
                                <div class="room-meta clearfix">
                                    <div class="price">
                                        <span class="title-price">From:</span>
                                        <span class="price_value price_min">BDT 4500</span>
                                        <span class="unit">Night</span>
                                    </div>
                                    <div class="rating"><span class="star"></span></div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="room col-sm-4 clearfix">
                        <div class="room-item">
                            <div class="room-media">
                                <a href="room-single.php"><img src="images/gallery/img-9.jpg" alt=""></a>
                            </div>
                            <div class="room-summary">
                                <h3 class="room-title">
                                    <a href="room-single.php">Juniour Officer's Room</a>
                                </h3>
                                <ul class="room-info">
                                    <li>18 m2</li>
                                    <li><span class="separator"></span></li>
                                    <li>Balcony</li>
                                    <li><span class="separator"></span></li>
                                    <li>Lake view</li>
                                </ul>
                                <div class="line"></div>
                                <div class="room-meta clearfix">
                                    <div class="price">
                                        <span class="title-price">From:</span>
                                        <span class="price_value price_min">BDT 1500</span>
                                        <span class="unit">Night</span>
                                    </div>
                                    <div class="rating"><span class="star"></span></div>
                                </div>

                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php include 'inc/footer.php'; ?>