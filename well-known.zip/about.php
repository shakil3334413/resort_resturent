
    <?php 
        include 'inc/header.php';
        include 'inc/menubar.php';
        include 'inc/mobile-menu.php'; 
    ?>

    <!-- Main Content -->
    <div id="main-content">
        <div class="page-title">
            <div class="page-title-wrapper" data-stellar-background-ratio="0.5">
                <div class="content container">
                    <h1 class="heading_primary">About Us</h1>
                    <ul class="breadcrumbs">
                        <li class="item"><a href="index.html">Home</a></li>
                        <li class="item"><span class="separator"></span></li>
                        <li class="item active">About Us</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="site-content no-padding">
            <div class="page-content">
                <div class="container">
                    <div class="empty-space"></div>
                    <div class="sc-heading">
                        <p class="first-title">WELCOME TO</p>
                        <h3 class="second-title">OUR HOTEL</h3>
                    </div>
                    <div class="about-info row">
                        <div class="col-sm-6">
                            <p>Hotel WP is a leader in the global hospitality industry, with a distinctive collection and a worldwide reputation for excellence. Our diverse portfolio includes historic icons, elegant resorts and modern city center properties. All of our hotels offer a superior guest experience that is uniquely ”Hotel WP”.</p>
                        </div>
                        <div class="col-sm-6">
                            <p>We guarantee consistency throughout our collection of hotels and resorts by adhering strictly to company-wide standards. Central purchasing ensures the same high-quality amenities are available to all guests wherever they visit. All these and more make every Hotel WP an extraordinary place.</p>
                        </div>
                    </div>
                    <div class="empty-space"></div>
                    <div class="sc-about-slides row">
                        <ul class="slides owl-theme owl-carousel">
                            <li><img src="images/gallery/img-1.jpg" alt=""></li>
                            <li><img src="images/gallery/img-8.jpg" alt=""></li>
                            <li><img src="images/gallery/img-3.jpg" alt=""></li>
                            <li><img src="images/gallery/img-4.jpg" alt=""></li>
                            <li><img src="images/gallery/img-5.jpg" alt=""></li>
                            <li><img src="images/gallery/img-6.jpg" alt=""></li>
                            <li><img src="images/gallery/img-7.jpg" alt=""></li>
                            <li><img src="images/gallery/img-2.jpg" alt=""></li>
                        </ul>
                    </div>
                </div>
                <div class="empty-space"></div>

                <div class="sc-counter-box">
                    <div class="sc-content-overlay">
                        <div class="container">
                            <div class="wrapper clearfix">
                                <div class="item">
                                    <div class="number">
                                        <span class="counter-up" data-number="32">0</span>
                                    </div>
                                    <div class="text">Rooms</div>
                                </div>
                                <div class="item">
                                    <div class="number">
                                        <span class="counter-up" data-number="50">0</span>
                                    </div>
                                    <div class="text">Staffs</div>
                                </div>
                                <div class="item">
                                    <div class="number">
                                        <span class="counter-up" data-number="100">0</span>
                                    </div>
                                    <div class="text">Menus</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="empty-space"></div>
                <div class="container">
                    <div class="sc-heading">
                        <p class="first-title">WHY CHOOSE</p>
                        <h3 class="second-title">OUR HOTEL</h3>
                    </div>
                    <div class="sc-list-info">
                        <div class="row">
                            <div class="col-sm-4">
                                <ul>
                                    <li><i class="ion-checkmark-circled"></i>Airport Pick Up & Drop Service</li>
                                    <li><i class="ion-checkmark-circled"></i>Unparalleded service</li>
                                    <li><i class="ion-checkmark-circled"></i>Free Wifi</li>
                                </ul>
                                <div class="image"><img src="images/gallery/img-3.jpg" alt=""></div>
                            </div>
                            <div class="col-sm-4">
                                <ul>
                                    <li><i class="ion-checkmark-circled"></i>Daily Mineral Water (1.5 Litter)</li>
                                    <li><i class="ion-checkmark-circled"></i>Unparalleded service</li>
                                    <li><i class="ion-checkmark-circled"></i>Product Catalogue</li>
                                </ul>
                                <div class="image"><img src="images/gallery/img-6.jpg" alt=""></div>
                            </div>
                            <div class="col-sm-4">
                                <ul>
                                    <li><i class="ion-checkmark-circled"></i>High satisfaction</li>
                                    <li><i class="ion-checkmark-circled"></i>Bar & garden with terrace</li>
                                    <li><i class="ion-checkmark-circled"></i>Wellness & pool</li>
                                </ul>
                                <div class="image"><img src="images/gallery/img-5.jpg" alt=""></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="empty-space"></div>
                <div class="sc-quote style-01">
                    <div class="sc-content-overlay">
                        <div class="container">
                            <div class="content">
                                <h3 class="title">Request Our 2018 Product Catalogue</h3>
                                <a href="#" class="btn-quote">GET A CATALOGUE </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php include 'inc/footer.php'; ?>