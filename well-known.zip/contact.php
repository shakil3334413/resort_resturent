    <?php 
        include 'inc/header.php';
        include 'inc/menubar.php';
        include 'inc/mobile-menu.php'; 
    ?>
    <!-- nav.mobile-menu-container -->

    <!-- Main Content -->
    <div id="main-content">
        <div class="page-title">
            <div class="page-title-wrapper" data-stellar-background-ratio="0.5">
                <div class="content container">
                    <h1 class="heading_primary">Contact</h1>
                    <ul class="breadcrumbs">
                        <li class="item"><a href="index.php">Home</a></li>
                        <li class="item"><span class="separator"></span></li>
                        <li class="item active">Contact</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="site-content no-padding">
            <div class="page-content">
                <div class="container">
                    <div class="empty-space"></div>
                    <div class="row tm-flex">
                        <div class="col-sm-6">
                            <div class="sc-heading">
                                <p class="first-title">SEND A</p>
                                <h3 class="second-title">MESSAGE</h3>
                                <p class="description">Do you have anything in your mind to tell us? <br>
                                    Please don't hesitate to get in touch to us via our contact form.</p>
                            </div>

                            <div class="sc-contact-form">
                                <form action="#" id="ajaxform" method="post">
                                    <input type="text" name="your-name" required placeholder="Your name*">
                                    <input type="email" name="your-email" required placeholder="Your email*">
                                    <input type="tel" name="your-phone" required placeholder="Your phone*">
                                    <textarea name="your-message" id="your-message" cols="30" rows="10" required placeholder="Your message*"></textarea>
                                    <input type="submit" class="submit" value="Send message">
                                </form>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="sc-contact-info">
                                <div class="sc-heading">
                                    <p class="first-title">GET IN TOUCH</p>
                                    <p class="description"><a href="contact.php#google-map">Eque's Heritage Hotel and Resort</br>Airport Road, Near By Fivestar Play Ground</br>Saidpur-5310, Nilphamari, Bangladesh</a></p>
                                </div>
                                <p class="phone">Call: <a href="tel:+8801794340979">+8801794340979</a></p>
                                <p class="email">Email: <a href="mailto:info@equeheritageresort.com">info@equeheritageresort.com</a></p>
                                <ul class="sc-social-link style-03">
                                    <li><a target="_blank" class="face" href="https://www.facebook.com/thimpress/"
                                           title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                    <li><a target="_blank" class="twitter" href="https://www.twitter.com/thimpress/"
                                           title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                    <li><a target="_blank" class="skype" href="skype:hotamdhv?call" title="Skype"><i
                                            class="fa fa-skype"></i></a></li>
                                    <li><a class="instagram" href="http://www.thimpress.com/" title="Instagram"><i
                                            class="fa fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="sc-google-map" id="sc-google-map">
                    <div class="empty-space"></div>
                    <div id="google-map"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php include 'inc/footer.php'; ?>