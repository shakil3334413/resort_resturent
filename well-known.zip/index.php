<?php 
    include 'inc/header.php'; 
    include 'inc/menubar.php';
    include 'inc/mobile-menu.php'; 
 ?>

    <!-- Main Content -->
    <div id="main-content" class="main-content">
        <div id="home-main-content" class="home-main-content home-1">
            <div id="rev_slider_2_1_wrapper" class="rev_slider_wrapper fullscreen-container no-mask-bg" data-alias="home-3"
                 data-source="gallery"
                 style="padding:0px;background-image:url('images/slides/h3-slider3.jpg');background-repeat:no-repeat;background-size:cover;background-position:center center;">
                <!-- START REVOLUTION SLIDER 5.4.7.4 fullscreen mode -->
                <!--<div id="rev_slider_2_1" class="fullscreenbanner" style="display:none;" data-version="5.4.7.4">-->
                    <!--<ul>-->
                        <!-- SLIDE  -->
                    <!--    <li data-index="rs-6" data-transition="fade" data-slotamount="default" data-hideafterloop="0"-->
                    <!--        data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300"-->
                    <!--        data-thumb="images/slides/h3-slider3-100x50.jpg" data-rotate="0" data-saveperformance="off"-->
                    <!--        data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5=""-->
                    <!--        data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">-->
                            <!-- MAIN IMAGE -->
                    <!--        <img src="images/slides/h3-slider3.jpg" alt="" data-bgposition="center center" data-bgfit="cover"-->
                    <!--             data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>-->
                            <!-- LAYERS -->

                            <!-- LAYER NR. 7 -->
                    <!--        <h1 class="tp-caption   tp-resizeme"-->
                    <!--            id="slide-6-layer-1"-->
                    <!--            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"-->
                    <!--            data-y="['middle','middle','middle','middle']" data-voffset="['-60','-60','-60','-60']"-->
                    <!--            data-fontsize="['64','64','64','40']"-->
                    <!--            data-width="none"-->
                    <!--            data-height="none"-->
                    <!--            data-whitespace="nowrap"-->

                    <!--            data-type="text"-->
                    <!--            data-responsive_offset="on"-->

                    <!--            data-frames='[{"from":"x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;","speed":1500,"to":"o:1;","delay":300,"ease":"Power3.easeInOut"},{"delay":"wait","speed":100,"to":"opacity:0;","ease":"Power2.easeIn"}]'-->
                    <!--            data-textAlign="['center','center','center','center']"-->
                    <!--            data-paddingtop="[0,0,0,0]"-->
                    <!--            data-paddingright="[0,0,0,0]"-->
                    <!--            data-paddingbottom="[0,0,0,0]"-->
                    <!--            data-paddingleft="[0,0,0,0]"-->

                    <!--            style="z-index: 11; white-space: nowrap; font-size: 64px; font-weight: 700; color: rgba(255,255,255,1);text-transform:uppercase;">-->
                    <!--            A Five Star Hotel </h1>-->

                            <!-- LAYER NR. 8 -->
                    <!--        <p class="tp-caption   tp-resizeme"-->
                    <!--           id="slide-6-layer-2"-->
                    <!--           data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"-->
                    <!--           data-y="['middle','middle','middle','middle']" data-voffset="['5','5','5','5']"-->
                    <!--           data-width="none"-->
                    <!--           data-height="none"-->
                    <!--           data-whitespace="nowrap"-->

                    <!--           data-type="text"-->
                    <!--           data-responsive_offset="on"-->

                    <!--           data-frames='[{"from":"y:bottom;rX:-20deg;rY:-20deg;rZ:0deg;","speed":1500,"to":"o:1;","delay":900,"ease":"Power3.easeOut"},{"delay":"wait","speed":300,"to":"y:[-100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"nothing"}]'-->
                    <!--           data-textAlign="['left','left','left','left']"-->
                    <!--           data-paddingtop="[0,0,0,0]"-->
                    <!--           data-paddingright="[0,0,0,0]"-->
                    <!--           data-paddingbottom="[0,0,0,0]"-->
                    <!--           data-paddingleft="[0,0,0,0]"-->

                    <!--           style="z-index: 12; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: rgba(255,255,255,1);">-->
                    <!--            And We Like To Keep It That Way! </p>-->

                            <!-- LAYER NR. 9 -->
                    <!--        <div class="tp-caption   tp-resizeme  thim-link-slider"-->
                    <!--             id="slide-6-layer-3"-->
                    <!--             data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"-->
                    <!--             data-y="['middle','middle','middle','middle']" data-voffset="['60','60','60','60']"-->
                    <!--             data-width="none"-->
                    <!--             data-height="none"-->
                    <!--             data-whitespace="nowrap"-->

                    <!--             data-type="text"-->
                    <!--             data-responsive_offset="on"-->

                    <!--             data-frames='[{"from":"y:bottom;rX:-20deg;rY:-20deg;rZ:0deg;","speed":1500,"to":"o:1;","delay":900,"ease":"Power3.easeOut"},{"delay":"wait","speed":100,"to":"opacity:0;","ease":"nothing"}]'-->
                    <!--             data-textAlign="['left','left','left','left']"-->
                    <!--             data-paddingtop="[0,0,0,0]"-->
                    <!--             data-paddingright="[0,0,0,0]"-->
                    <!--             data-paddingbottom="[0,0,0,0]"-->
                    <!--             data-paddingleft="[0,0,0,0]"-->

                    <!--             style="z-index: 13; white-space: nowrap; font-size: 15px; font-weight: 700; color: rgba(255,255,255,1);text-transform:uppercase;">-->
                    <!--            <a href="#">Contact Us</a></div>-->
                    <!--    </li>-->
                        <!-- SLIDE  -->
                    <!--    <li data-index="rs-5" data-transition="fade" data-slotamount="default" data-hideafterloop="0"-->
                    <!--        data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300"-->
                    <!--        data-thumb="images/slides/h3-slider2-100x50.jpg" data-rotate="0" data-saveperformance="off"-->
                    <!--        data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5=""-->
                    <!--        data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">-->
                            <!-- MAIN IMAGE -->
                    <!--        <img src="images/slides/h3-slider2.jpg" alt="" data-bgposition="center center" data-bgfit="cover"-->
                    <!--             data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>-->
                            <!-- LAYERS -->

                            <!-- LAYER NR. 4 -->
                    <!--        <h1 class="tp-caption   tp-resizeme"-->
                    <!--            id="slide-5-layer-1"-->
                    <!--            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"-->
                    <!--            data-y="['middle','middle','middle','middle']" data-voffset="['-60','-60','-60','-60']"-->
                    <!--            data-fontsize="['64','64','50','32']"-->
                    <!--            data-width="none"-->
                    <!--            data-height="none"-->
                    <!--            data-whitespace="nowrap"-->

                    <!--            data-type="text"-->
                    <!--            data-responsive_offset="on"-->

                    <!--            data-frames='[{"from":"y:[100%];z:0;rZ:-35deg;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":2000,"to":"o:1;","delay":300,"split":"chars","splitdelay":0.05,"ease":"Power4.easeInOut"},{"delay":"wait","speed":100,"to":"opacity:0;","ease":"Power2.easeIn"}]'-->
                    <!--            data-textAlign="['center','center','center','center']"-->
                    <!--            data-paddingtop="[0,0,0,0]"-->
                    <!--            data-paddingright="[0,0,0,0]"-->
                    <!--            data-paddingbottom="[0,0,0,0]"-->
                    <!--            data-paddingleft="[0,0,0,0]"-->

                    <!--            style="z-index: 8; white-space: nowrap; font-size: 64px; font-weight: 700; color: rgba(255,255,255,1);text-transform:uppercase;">-->
                    <!--            Book Early Save More </h1>-->

                            <!-- LAYER NR. 5 -->
                    <!--        <p class="tp-caption   tp-resizeme"-->
                    <!--           id="slide-5-layer-2"-->
                    <!--           data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"-->
                    <!--           data-y="['middle','middle','middle','middle']" data-voffset="['5','5','5','5']"-->
                    <!--           data-width="none"-->
                    <!--           data-height="none"-->
                    <!--           data-whitespace="nowrap"-->

                    <!--           data-type="text"-->
                    <!--           data-responsive_offset="on"-->

                    <!--           data-frames='[{"from":"x:[105%];z:0;rX:45deg;rY:0deg;rZ:90deg;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":2000,"to":"o:1;","delay":500,"split":"chars","splitdelay":0.05,"ease":"Power4.easeInOut"},{"delay":"wait","speed":100,"to":"opacity:0;","ease":"Power2.easeIn"}]'-->
                    <!--           data-textAlign="['left','left','left','left']"-->
                    <!--           data-paddingtop="[0,0,0,0]"-->
                    <!--           data-paddingright="[0,0,0,0]"-->
                    <!--           data-paddingbottom="[0,0,0,0]"-->
                    <!--           data-paddingleft="[0,0,0,0]"-->

                    <!--           style="z-index: 9; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: rgba(255,255,255,1);">-->
                    <!--            Room Availability Checker and Booking </p>-->

                            <!-- LAYER NR. 6 -->
                    <!--        <div class="tp-caption   tp-resizeme  thim-link-slider"-->
                    <!--             id="slide-5-layer-3"-->
                    <!--             data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"-->
                    <!--             data-y="['middle','middle','middle','middle']" data-voffset="['60','60','60','60']"-->
                    <!--             data-width="none"-->
                    <!--             data-height="none"-->
                    <!--             data-whitespace="nowrap"-->

                    <!--             data-type="text"-->
                    <!--             data-responsive_offset="on"-->

                    <!--             data-frames='[{"from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":1300,"ease":"Power3.easeInOut"},{"delay":"wait","speed":100,"to":"opacity:0;","ease":"Power2.easeIn"}]'-->
                    <!--             data-textAlign="['left','left','left','left']"-->
                    <!--             data-paddingtop="[0,0,0,0]"-->
                    <!--             data-paddingright="[0,0,0,0]"-->
                    <!--             data-paddingbottom="[0,0,0,0]"-->
                    <!--             data-paddingleft="[0,0,0,0]"-->

                    <!--             style="z-index: 10; white-space: nowrap; font-size: 15px; font-weight: 700; color: rgba(255,255,255,1);text-transform:uppercase;">-->
                    <!--            <a href="#">Explore</a></div>-->
                    <!--    </li>-->
                        <!-- SLIDE  -->
                    <!--    <li data-index="rs-4" data-transition="fade" data-slotamount="default" data-hideafterloop="0"-->
                    <!--        data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300"-->
                    <!--        data-thumb="images/slides/h3-slider1-100x50.jpg" data-rotate="0" data-saveperformance="off"-->
                    <!--        data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5=""-->
                    <!--        data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">-->
                            <!-- MAIN IMAGE -->
                    <!--        <img src="images/slides/h3-slider1.jpg" alt="" data-bgposition="center center" data-bgfit="cover"-->
                    <!--             data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>-->
                            <!-- LAYERS -->

                            <!-- LAYER NR. 1 -->
                    <!--        <h1 class="tp-caption   tp-resizeme"-->
                    <!--            id="slide-4-layer-1"-->
                    <!--            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"-->
                    <!--            data-y="['middle','middle','middle','middle']" data-voffset="['-60','-60','-60','-60']"-->
                    <!--            data-fontsize="['64','64','64','40']"-->
                    <!--            data-width="none"-->
                    <!--            data-height="none"-->
                    <!--            data-whitespace="nowrap"-->

                    <!--            data-type="text"-->
                    <!--            data-responsive_offset="on"-->

                    <!--            data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":900,"ease":"Power3.easeInOut"},{"delay":"wait","speed":100,"to":"y:-50px;opacity:0;","ease":"nothing"}]'-->
                    <!--            data-textAlign="['center','center','center','center']"-->
                    <!--            data-paddingtop="[0,0,0,0]"-->
                    <!--            data-paddingright="[0,0,0,0]"-->
                    <!--            data-paddingbottom="[0,0,0,0]"-->
                    <!--            data-paddingleft="[0,0,0,0]"-->

                    <!--            style="z-index: 5; white-space: nowrap; font-size: 64px; font-weight: 700; color: rgba(255,255,255,1);">-->
                    <!--            DUBROVNIK DELUXE </h1>-->

                            <!-- LAYER NR. 2 -->
                    <!--        <p class="tp-caption   tp-resizeme"-->
                    <!--           id="slide-4-layer-2"-->
                    <!--           data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"-->
                    <!--           data-y="['middle','middle','middle','middle']" data-voffset="['5','5','5','5']"-->
                    <!--           data-width="none"-->
                    <!--           data-height="none"-->
                    <!--           data-whitespace="nowrap"-->

                    <!--           data-type="text"-->
                    <!--           data-responsive_offset="on"-->

                    <!--           data-frames='[{"from":"y:bottom;rX:-20deg;rY:-20deg;rZ:0deg;","speed":1500,"to":"o:1;","delay":900,"ease":"Power3.easeOut"},{"delay":"wait","speed":300,"to":"y:[-100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"nothing"}]'-->
                    <!--           data-textAlign="['left','left','left','left']"-->
                    <!--           data-paddingtop="[0,0,0,0]"-->
                    <!--           data-paddingright="[0,0,0,0]"-->
                    <!--           data-paddingbottom="[0,0,0,0]"-->
                    <!--           data-paddingleft="[0,0,0,0]"-->

                    <!--           style="z-index: 6; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: rgba(255,255,255,1);">-->
                    <!--            Hotel Excelsior Dubrovnik from €488 per night </p>-->

                            <!-- LAYER NR. 3 -->
                    <!--        <div class="tp-caption   tp-resizeme  thim-link-slider"-->
                    <!--             id="slide-4-layer-3"-->
                    <!--             data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"-->
                    <!--             data-y="['middle','middle','middle','middle']" data-voffset="['60','60','60','60']"-->
                    <!--             data-width="none"-->
                    <!--             data-height="none"-->
                    <!--             data-whitespace="nowrap"-->

                    <!--             data-type="text"-->
                    <!--             data-responsive_offset="on"-->

                    <!--             data-frames='[{"from":"y:bottom;rX:-20deg;rY:-20deg;rZ:0deg;","speed":1500,"to":"o:1;","delay":900,"ease":"Power3.easeOut"},{"delay":"wait","speed":100,"to":"opacity:0;","ease":"nothing"}]'-->
                    <!--             data-textAlign="['left','left','left','left']"-->
                    <!--             data-paddingtop="[0,0,0,0]"-->
                    <!--             data-paddingright="[0,0,0,0]"-->
                    <!--             data-paddingbottom="[0,0,0,0]"-->
                    <!--             data-paddingleft="[0,0,0,0]"-->

                    <!--             style="z-index: 7; white-space: nowrap; font-size: 15px; font-weight: 700; color: rgba(255,255,255,1);text-transform:uppercase;">-->
                    <!--            <a href="#">Discover</a></div>-->
                    <!--    </li>-->
                    <!--</ul>-->
                    
                   
                    <div class="room-single row">
                        <main class="site-main col-md-12 flex-first">
                            <div class="room-wrapper">
                                <div class="room_gallery clearfix">
                                    <div class="camera_wrap camera_emboss" id="camera_wrap">
                                        <div  data-src="images/slides/h1-slider1.jpg"></div>
                                        <div  data-src="images/slides/h1-slider3.jpg"></div>
                                        <div  data-src="images/slides/h1-slider2.jpg"></div>
                                    </div>
                                </div>
                           </div>
                        </main>
                    </div>
                    
                    
                    
                    <!--<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>-->
                <!--</div>-->
                 
            </div><!-- END REVOLUTION SLIDER -->

                       
                        
            <div class="empty-space"></div>
            <div class="container">
                <div class="sc-heading">
                    <p class="first-title">WELCOME TO</p>
                    <h3 class="second-title">OUR HOTEL</h3>
                </div>
                <div class="sc-info about-info row">
                    <div class="col-sm-6">
                        <p>Hotel TQ is a leader in the global hospitality industry, with a distinctive collection and a worldwide reputation for excellence. Our diverse portfolio includes historic icons, elegant resorts and modern city center properties. All of our hotels offer a superior guest experience that is uniquely ”Hotel WP”.</p>
                        <a href="about-us.html" class="btn-icon">Read More</a>
                    </div>
                    <div class="col-sm-6">
                        <div class="sc-hb-rooms-search style-01">
                            <div class="hotel-booking-search style-01 layout-columns">
                                <form action="http://html.thimpress.com/hotelwp/rooms-search.html" class="hb-search-form">
                                    <ul class="hb-form-table clearfix">
                                        <li><input type="text" id="multidate2" class="multidate" value="" data-date-min="6" /></li>
                                        <li class="hb-form-field hb-form-check-in">
                                            <div class="label">Check-In</div>
                                            <div class="hb-form-field-input hb_input_field">
                                                <input id="month" class="month" type="text" value="" />
                                                <input type="text" id="day" class="day" value="" style="width: 68px;" />
                                                <input type="hidden" name="check_in_date" id="check_in_date" class="check-date hasDatepicker" value="" />
                                            </div>
                                        </li>

                                        <li class="hb-form-field hb-form-check-out">
                                            <div class="label">Check-Out</div>
                                            <div class="hb-form-field-input hb_input_field">
                                                <input id="month2" class="month" type="text" value="" />
                                                <input type="text" id="day2" class="day" value="" style="width: 83px;" />
                                                <input type="hidden" name="check_out_date" id="check_out_date" class="check-date hasDatepicker" value="" />
                                            </div>
                                        </li>

                                        <li class="hb-form-field hb-form-number">
                                            <div class="label">Guests</div>
                                            <div id="guests" class="hb-form-field-input hb_input_field">
                                                <span class="number-icons goUp"><i class="icomoon icon-up"></i></span>
                                                <select name="adults_capacity" tabindex="-1" aria-hidden="true">
                                                    <option value="47">1</option>
                                                    <option value="45">2</option>
                                                    <option value="56">3</option>
                                                    <option value="57">4</option>
                                                    <option value="58">5</option>
                                                    <option value="59">6</option>
                                                    <option value="60">7</option>
                                                    <option value="61">8</option>
                                                    <option value="62">9</option>
                                                </select>
                                                <span class="number-icons goDown"><i class="icomoon icon-up"></i></span>

                                            </div>
                                        </li>

                                    </ul>
                                    <div class="hb-submit">
                                        <div class="contact-info">
                                            <p>Can we help you? Call us!</p>
                                        <p><a href="tel:+8801406767067">+8801406767067</a></p>
                                        </div>
                                        <button type="submit">Check Availability</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="empty-space"></div>
            <div class="sc-categories-link style-02">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="item">
                                <img src="images/home/h2-img1.jpg" alt="">
                                <a href="rooms.php" class="img-link"></a>
                                <div class="content-overlay">
                                    <h4 class="title"><a href="rooms.php">Rooms</a></h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="item">
                                <img src="images/home/h2-img2.jpg" alt="">
                                <a href="gallery-full-width.html" class="img-link"></a>
                                <div class="content-overlay">
                                    <h4 class="title"><a href="gallery-full-width.html">Restaurant</a></h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="item">
                                <img src="images/home/h2-img4.jpg" alt="">
                                <a href="gallery-full-width.html" class="img-link"></a>                                
								<div class="content-overlay">
                                <h4 class="title"><a href="gallery-full-width.html">Swimming Pool</a></h4>
                            </div>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="item">
                                <img src="images/home/h2-img3.jpg" alt="">
                                <a href="gallery-full-width.html" class="img-link"></a>
                                <div class="content-overlay">
                                    <h4 class="title"><a href="gallery-full-width.html">Graden</a></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="empty-space"></div>
            <div class="sc-quote style-02">
                <div class="sc-content-overlay">
                    <div class="container">
                        <div class="content">
                            <h3 class="title"><span><b>Take advantage</b> of our <br>
                                seasonal specials.</span></h3>
                            <a href="#" class="btn-quote">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="empty-space"></div>
            <div class="sc-rooms style-02">
                <div class="container">
                    <div class="sc-heading style-03">
                        <p class="first-title">EXPLORE</p>
                        <h3 class="second-title">OUR ROOMS</h3>
                        <a href="rooms.html" class="btn-right view-rooms">View Rooms</a>
                    </div>
                    <div class="rooms-content layout-grid style-02">
                        <div class="row">
                            <div class="room col-sm-4 clearfix">
                                <div class="room-item">
                                    <div class="room-media">
                                        <a href="room-single.php"><img src="images/gallery/img-4.jpg" alt=""></a>
                                    </div>
                                    <div class="room-summary">
                                        <h3 class="room-title">
                                            <a href="room-single.html">Classic Room</a>
                                        </h3>
                                        <ul class="room-info">
                                            <li>18 m2</li>
                                            <li><span class="separator"></span></li>
                                            <li>Balcony</li>
                                            <li><span class="separator"></span></li>
                                            <li>Lake view</li>
                                        </ul>
                                        <div class="line"></div>
                                        <div class="room-meta clearfix">
                                            <div class="price">
                                                <span class="title-price">From:</span>
                                                <span class="price_value price_min">$100.0</span>
                                                <span class="unit">Night</span>
                                            </div>
                                            <div class="rating"><span class="star"></span></div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="room col-sm-4 clearfix">
                                <div class="room-item">
                                    <div class="room-media">
                                        <a href="room-single.html"><img src="images/gallery/img-11.jpg" alt=""></a>
                                    </div>
                                    <div class="room-summary">
                                        <h3 class="room-title">
                                            <a href="room-single.html">Budget Room</a>
                                        </h3>
                                        <ul class="room-info">
                                            <li>18 m2</li>
                                            <li><span class="separator"></span></li>
                                            <li>Balcony</li>
                                            <li><span class="separator"></span></li>
                                            <li>Lake view</li>
                                        </ul>
                                        <div class="line"></div>
                                        <div class="room-meta clearfix">
                                            <div class="price">
                                                <span class="title-price">From:</span>
                                                <span class="price_value price_min">$100.0</span>
                                                <span class="unit">Night</span>
                                            </div>
                                            <div class="rating"><span class="star"></span></div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="room col-sm-4 clearfix">
                                <div class="room-item">
                                    <div class="room-media">
                                        <a href="room-single.html"><img src="images/gallery/img-6.jpg" alt=""></a>
                                    </div>
                                    <div class="room-summary">
                                        <h3 class="room-title">
                                            <a href="room-single.html">Premium Room</a>
                                        </h3>
                                        <ul class="room-info">
                                            <li>18 m2</li>
                                            <li><span class="separator"></span></li>
                                            <li>Balcony</li>
                                            <li><span class="separator"></span></li>
                                            <li>Lake view</li>
                                        </ul>
                                        <div class="line"></div>
                                        <div class="room-meta clearfix">
                                            <div class="price">
                                                <span class="title-price">From:</span>
                                                <span class="price_value price_min">$100.0</span>
                                                <span class="unit">Night</span>
                                            </div>
                                            <div class="rating"><span class="star"></span></div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="empty-space"></div>
            <div class="h2-testimonials">
                <div class="sc-content-overlay">
                    <div class="container">
                        <div class="sc-testimonials style-02 pull-right">
                            <div class="sc-heading">
                                <p class="first-title">PEOPLE REVIEWS</p>
                            </div>
                            <div class="testimonial-slider2 owl-carousel owl-theme">
                                <div class="item">
                                    <div class="content">
                                        " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam porta sem malesuada magna mollis euismod. Nul id dolor id nibh ultricies vehicula ut id elit. "
                                    </div>
                                    <p class="review"><span class="rating-star"></span></p>
                                    <p class="name">Bobby</p>
                                </div>
                                <div class="item">
                                    <div class="content">
                                        " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam porta sem malesuada magna mollis euismod. Nul id dolor id nibh ultricies vehicula ut id elit. "
                                    </div>
                                    <p class="review"><span class="rating-star"></span></p>
                                    <p class="name">Neman</p>
                                </div>
                                <div class="item">
                                    <div class="content">
                                        " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam porta sem malesuada magna mollis euismod. Nul id dolor id nibh ultricies vehicula ut id elit. "
                                    </div>
                                    <p class="review"><span class="rating-star"></span></p>
                                    <p class="name">Stephens</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="empty-space"></div>
            <div class="container blog-event">
                <div class="row">
                    <div class="col-sm-6 col-md-8 item-first">
                        <div class="sc-heading style-03">
                            <p class="first-title">FROM</p>
                            <h3 class="second-title">OUR BLOG</h3>
                        </div>
                        <div class="sc-post style-02">
                            <div class="row">
                                <div class="post col-sm-6">
                                    <div class="post-content">
                                        <div class="post-media">
                                            <a href="blog-single.html"><img src="images/gallery/img-3.jpg" alt=""></a>
                                        </div>
                                        <div class="post-summary">
                                            <div class="meta"><span class="date">July 15, 2018</span></div>
                                            <h4 class="title"><a href="blog-single.html">10 Things You Should Know</a></h4>
                                            <div class="readmore">
                                                <a href="blog-single.html" class="btn-icon">Read More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="post col-sm-6">
                                    <div class="post-content">
                                        <div class="post-media">
                                            <a href="blog-single.html"><img src="images/gallery/img-5.jpg" alt=""></a>
                                        </div>
                                        <div class="post-summary">
                                            <div class="meta"><span class="date">July 18, 2018</span></div>
                                            <h4 class="title"><a href="blog-single.html">Live your myth in VietNam</a></h4>
                                            <div class="readmore">
                                                <a href="blog-single.html" class="btn-icon">Read More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 item-second">
                        <div class="sc-heading style-03">
                            <p class="first-title">NEXT</p>
                            <h3 class="second-title">EVENTS</h3>
                        </div>
                        <div class="sc-list-event style-01">
                            <div class="list">
                                <div class="event clearfix">
                                    <div class="time-from">
                                        <div class="date">15</div>
                                        <div class="month">Jul</div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title"><a href="event-single.html">Hotel Film Festival</a></h4>
                                    </div>
                                </div>
                                <div class="event clearfix">
                                    <div class="time-from">
                                        <div class="date">15</div>
                                        <div class="month">SEP</div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title"><a href="event-single.html">Flash Chorus On The Roof</a></h4>
                                    </div>
                                </div>
                                <div class="event clearfix">
                                    <div class="time-from">
                                        <div class="date">20</div>
                                        <div class="month">SEP</div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title"><a href="event-single.html">Alan Walker in Hotel</a></h4>
                                    </div>
                                </div>
                            </div>
                            <a href="events.html" class="btn-icon"> Read More</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="empty-space"></div>
            <div class="container">
                <div class="sc-heading style-03">
                    <p class="first-title">FACEBOOK</p>
                </div>
            </div>
            <div class="sc-instagram">
                <div class="container-fluid">
                    <div class="row">
                        <div class="item">
                            <a href="https://www.instagram.com/p/Bc_4LVwF6U_/" target="_blank"><img src="images/home/h2-instagram1.jpg" alt=""></a>
                        </div>
                        <div class="item">
                            <a href="https://www.instagram.com/p/Bc_39pRl1rr/" target="_blank"><img src="images/home/h2-instagram2.jpg" alt=""></a>
                        </div>
                        <div class="item">
                            <a href="https://www.instagram.com/p/Bc_3zm-FaaN/" target="_blank"><img src="images/home/h2-instagram3.jpg" alt=""></a>
                        </div>
                        <div class="item">
                            <a href="https://www.instagram.com/p/Bc_3RLwFwgb/" target="_blank"><img src="images/home/h2-instagram4.jpg" alt=""></a>
                        </div>
                        <div class="item">
                            <a href="https://www.instagram.com/p/BcQ-o3xlIX9/" target="_blank"><img src="images/home/h2-instagram5.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php include 'inc/footer.php'; ?>