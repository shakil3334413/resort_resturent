<?php 
    include 'inc/header.php';
    include 'inc/sidebar.php';
?>
<?php
    // header("Location: dashbord.php");
    header('Location: dashbord.php', true, 301);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv = "refresh" content = "0; url = dashbord.php" />
    <title>redirect</title>
    <Script>
        window.location = "dashbord.php";
    </Script>
</head>
<body>
    
</body>
</html>

<?php include 'inc/fooder.php' ?>  