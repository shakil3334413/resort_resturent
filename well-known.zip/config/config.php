<?php
define("DB_HOST", "localhost");
define("DB_USER", "equeheri_webadmin");
define("DB_PASS", "hxf_~0T!0vVnk.53t{");
define("DB_NAME", "equeheri_hotel");
