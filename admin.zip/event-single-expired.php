    <?php 
        include 'inc/header.php';
        include 'inc/menubar.php';
        include 'inc/mobile-menu.php'; 
    ?>
    <!-- nav.mobile-menu-container -->

    <!-- Main Content -->
    <div id="main-content">
        <div class="page-title">
            <div class="page-title-wrapper" data-stellar-background-ratio="0.5">
                <div class="content container">
                    <h1 class="heading_primary">Event Single</h1>
                    <ul class="breadcrumbs">
                        <li class="item"><a href="index.php">Home</a></li>
                        <li class="item"><span class="separator"></span></li>
                        <li class="item"><a href="events.php">Event</a></li>
                        <li class="item"><span class="separator"></span></li>
                        <li class="item active">Event Single</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="site-content container">
            <div class="row">
                <main class="site-main col-sm-12 col-md-9 flex-first">
                    <div class="event-single-content expired">
                        <div class="event clearfix">
                            <div class="wrapper">
                                <div class="thumbnail">
                                    <img src="images/gallery/music-party.jpg" alt="">
                                    <div class="thim-countdown notice">
                                        <span>This event has expired</span>
                                    </div>
                                </div>
                                <div class="content">
                                    <h2 class="title">Music Party</h2>
                                    <div class="detail clearfix">
                                        <div class="description">
                                            <h4>EVENT DESCRIPTION</h4>
                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic
                                                typesetting, remaining essentially unchanged.</p>
                                            <h4>EVENT CONTENT</h4>
                                            <ul class="event-list-content">
                                                <li>Over 37 lectures and 55.5 hours of content!</li>
                                                <li>LIVE PROJECT End to End Software Testing Training Included.</li>
                                                <li>Learn Software Testing and Automation basics from a professional trainer
                                                    from your own desk.
                                                </li>
                                                <li>Information packed practical training starting from basics to advanced
                                                    testing techniques.
                                                </li>
                                                <li>Best suitable for beginners to advanced level users and who learn faster
                                                    when demonstrated.
                                                </li>
                                                <li>Course content designed by considering current software testing
                                                    technology and the job market.
                                                </li>
                                                <li>Practical assignments at the end of every session.</li>
                                                <li>Practical learning experience with live project work and examples.</li>
                                            </ul>
                                        </div>
                                        <div class="info">
                                            <ul>
                                                <li class="title"><i class="fa fa-clock-o"></i>Start Time</li>
                                                <li class="item">8:00 am</li>
                                                <li class="item">Sunday, July 15, 2017</li>
                                            </ul>
                                            <ul>
                                                <li class="title"><i class="fa fa-clock-o"></i>Finish Time</li>
                                                <li class="item">5:00 pm</li>
                                                <li class="item">Sunday, July 01, 2018</li>
                                            </ul>
                                            <ul>
                                                <li class="title"><i class="fa fa fa-map-marker"></i>Address</li>
                                                <li class="item">Paris, French</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="social-share">
                                        <ul>
                                            <li><a class="link facebook" title="Facebook" href="http://www.facebook.com/sharer/sharer.php?u=#" rel="nofollow" onclick="window.open(this.href,this.title,'width=600,height=600,top=200px,left=200px');  return false;" target="_blank"><i class="ion-social-facebook"></i></a></li>
                                            <li><a class="link twitter" title="Twitter" href="https://twitter.com/intent/tweet?url=#&amp;text=TheTitleBlog" rel="nofollow" onclick="window.open(this.href,this.title,'width=600,height=600,top=200px,left=200px');  return false;" target="_blank"><i class="ion-social-twitter"></i></a></li>
                                            <li><a class="link pinterest" title="Pinterest" href="http://pinterest.com/pin/create/button/?url=#" onclick="window.open(this.href, 'mywin','left=50,top=50,width=600,height=350,toolbar=0'); return false;"><i class="ion-social-pinterest"></i></a></li>
                                            <li><a class="link google" title="Google" href="https://plus.google.com/share?url=#" rel="nofollow" onclick="window.open(this.href,this.title,'width=600,height=600,top=200px,left=200px');  return false;" target="_blank"><i class="ion-social-googleplus"></i></a>
                                            <li><a class="link linkedin" title="LinkedIn" href="http://www.linkedin.com/shareArticle/?url=#" rel="nofollow" onclick="window.open(this.href,this.title,'width=600,height=600,top=200px,left=200px');  return false;" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="comments-list" id="comments-list">
                                <h3 class="total-comments">comments</h3>
                                <ul>
                                    <li class="comment clearfix">
                                        <div class="comment-img">
                                            <img src="images/blog/author1.jpg" alt="">
                                        </div>
                                        <div class="comment-content">
                                            <h6>Anna Shubina</h6>
                                            <span>March 03, 2015</span>
                                            <a class="reply" href="#post-comment" title="Reply">Reply</a>
                                            <p>Paetos dignissim at cursus elefeind norma arcu. Pellentesque accumsan est in tempus etos ullamcorper, sem quam suscipit lacus maecenas tortor. Erates vitae node metus. Morbi suspendisse a tortor velim pellentesque uter justo magna gravida. Pellentesque accumsan, ex in tempus ullamcorper terminal.</p>
                                        </div>
                                        <ul class="children">
                                            <li class="comment clearfix">
                                                <div class="comment-img">
                                                    <img src="images/blog/author2.jpg" alt="">
                                                </div>

                                                <div class="comment-content">
                                                    <h6>Anna Shubina</h6>
                                                    <span>March 03, 2015</span>
                                                    <a class="reply" href="#post-comment" title="Reply">Reply</a>
                                                    <p>Paetos dignissim at cursus elefeind norma arcu. Pellentesque accumsan est in tempus etos ullamcorper, sem quam suscipit lacus maecenas tortor. Erates vitae node metus. Morbi suspendisse a tortor velim pellentesque uter justo magna gravida. Pellentesque accumsan, ex in tempus ullamcorper terminal.</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="comment clearfix">
                                        <div class="comment-img">
                                            <img src="images/blog/author1.jpg" alt="">
                                        </div>
                                        <div class="comment-content">
                                            <h6>Ann Smith</h6>
                                            <span>March 03, 2018</span>
                                            <a class="reply" href="#post-comment" title="Reply">Reply</a>
                                            <p>Paetos dignissim at cursus elefeind norma arcu. Pellentesque accumsan est in tempus etos ullamcorper, sem quam suscipit lacus maecenas tortor. Erates vitae node metus. Morbi suspendisse a tortor velim pellentesque uter justo magna gravida. Pellentesque accumsan, ex in tempus ullamcorper terminal.</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                            <div class="post-comment" id="post-comment">
                                <h3 class="reply-comment">leave a comment</h3>
                                <form action="#" method="post" id="comment-form">
                                    <p>Your email address will not be published. Required fields are marked *</p>
                                    <div class="row">
                                        <div class="col-sm-6"><input placeholder="Name *" id="name" name="name" type="text" value="" size="30" required></div>
                                        <div class="col-sm-6"><input placeholder="Email *" id="email" name="email" type="email" value="" size="30" required></div>
                                    </div>
                                    <textarea placeholder="Message *" name="message" id="message" cols="45" rows="8" required></textarea>
                                    <input name="submit" type="submit" id="submit" class="submit" value="Submit">
                                </form>
                            </div>
                        </div>
                    </div>
                </main>
                <aside id="secondary" class="widget-area col-sm-12 col-md-3 sticky-sidebar">
                    <div class="wd wd-book-event">
                        <h3 class="wd-title">Buy Ticket</h3>
                        <form role="search" method="POST" action="#" class="book_event">
                            <ul>
                                <li>
                                    <div class="label">Total Slots</div>
                                    <div class="value">500</div>
                                </li>
                                <li>
                                    <div class="label">Booked Slots</div>
                                    <div class="value">400</div>
                                </li>
                                <li class="event-cost">
                                    <div class="label">Cost</div>
                                    <div class="value">$10/Slot</div>
                                </li>
                                <li>
                                    <div class="label">Quantity</div>
                                    <div class="value"><input type="number" name="qty" value="1" min="1" /></div></li>
                            </ul>
                            <button type="submit" class="submit disabled" disabled>Expired</button>
                        </form>
                    </div>
                </aside>

            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php include 'inc/footer.php'; ?>