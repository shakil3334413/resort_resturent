<?php

/**
 * Format Class
 */
class Format {

   public function formatDate($date){
      return date('F j, Y, g:i a', strtotime($date));
   }

   public function textShorten($text, $limit = 400) {
      $text = $text . " ";
      $text = substr($text, 0, $limit);
      $text = substr($text, 0, strrpos($text, ' '));
      $text = $text . ".....";
      return $text;
   }

   public function validation($data){
      $data = trim($data);
      $data = stripcslashes($data);
      $data = htmlspecialchars($data);
      return $data;
   }

   public function title() {
      $path = $_SERVER['SCRIPT_FILENAME'];
      $title = basename($path, '.php');
      //$title = str_replace('_', ' ', $title);
      if ($title == 'index') {
         $title = "Eque's Heritage Hotel & Resort";
      } elseif ($title == 'about') {
         $title = "About Us";
      } elseif ($title == 'rooms') {
         $title = "Our Rooms";
      } elseif ($title == 'single') {
         $title = "A/C Single Deluxe";
      } elseif ($title == 'double') {
         $title = "A/C Double Deluxe";
      } elseif ($title == 'deluxe') {
         $title = "A/C Deluxe Suite";
      } elseif ($title == 'family') {
         $title = "A/C Eque Family Suite";
      } elseif ($title == 'officer') {
         $title = "Juniour Officer's Room";
      } elseif ($title == 'gallery') {
         $title = "Gallery";
      } elseif ($title == 'package') {
         $title = "Packages";
      } elseif ($title == 'events') {
         $title = "Events";
      } elseif ($title == 'event-single') {
         $title = "Event Single";
      } elseif ($title == 'event-single-expired') {
         $title = "Event Single Expired";
      } elseif ($title == 'contact') {
         $title = "Contact";
      } elseif ($title == "room-single") {
         $title = "Room Deatils";
      } elseif ($title == '404') {
         $title = "Page not found";
      } elseif ($title == 'blog-single') {
         $title = "Blog - Deatils";
      } elseif ($title == 'blog') {
         $title = "Blogs";
      } elseif ($title == '') {
         $title = "";
      }
      return $title = ucfirst($title);
   }

   public function newtitle(){
      $path = $_SERVER['SCRIPT_FILENAME'];
      $newtitle = basename($path, '.php');
      if ($newtitle == 'dashbord') {
         $newtitle = "Hotel Management";
      } elseif ($newtitle == 'booking_all') {
         $newtitle = "Booking List";
      } elseif ($newtitle == 'booking_edit') {
         $newtitle = "Edit Booking";
      } elseif ($newtitle == 'booking_add') {
         $newtitle = "Add Booking";
      } elseif ($newtitle == 'customers_list') {
         $newtitle = "Customers List";
      } elseif ($newtitle == 'customers_edit') {
         $newtitle = "Edit Customers";
      } elseif ($newtitle == 'customers_add') {
         $newtitle = "Add Customers";
      } elseif ($newtitle == 'rooms_list') {
         $newtitle = "Rooms List";
      } elseif ($newtitle == 'room_edit') {
         $newtitle = "Edit Room";
      } elseif ($newtitle == 'room_add') {
         $newtitle = "Add Room";
      } elseif ($newtitle == 'staff_list') {
         $newtitle = "Staff List";
      } elseif ($newtitle == 'staff_edit') {
         $newtitle = "Edit Staff";
      } elseif ($newtitle == 'staff_add') {
         $newtitle = "Add Staff";
      } elseif ($newtitle == 'pricing') {
         $newtitle = "Princing";
      } elseif ($newtitle == 'pricing_edit') {
         $newtitle = "Edit Princing";
      } elseif ($newtitle == 'pricing_add') {
         $newtitle = "Add Princing";
      } elseif ($newtitle == 'chat') {
         $newtitle = "Chat";
      } elseif ($newtitle == 'Employees List') {
         $newtitle == "Employees List";
      } elseif ($newtitle == 'employees_add') {
         $newtitle == "Add Employee";
      } elseif ($newtitle == 'employees_edit') {
         $newtitle == "Edit Employee";
      } elseif ($newtitle == 'leaves') {
         $newtitle == "Leaves";
      } elseif ($newtitle == 'Holidays') {
         $newtitle == "Holidays";
      } elseif ($newtitle == 'invoice') {
         $newtitle == "invoice";
      } elseif ($newtitle == 'provident_fund') {
         $newtitle == "Provident Fund";
      } elseif ($newtitle == 'salary') {
         $newtitle == "Salary";
      } elseif ($newtitle == 'salary_view') {
         $newtitle = "Payslip";
      } elseif ($newtitle == 'blog') {
         $newtitle == "Blog";
      } elseif ($newtitle == 'blog_details') {
         $newtitle == "Blog Detalis";
      } elseif ($newtitle == 'blog_add') {
         $newtitle == "Add Blog";
      } elseif ($newtitle == 'blog_edit') {
         $newtitle = "Edit Blog";
      }
      return $newtitle = ucfirst($newtitle);
   }

}