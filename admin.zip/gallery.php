    <?php 
        include 'inc/header.php';
        include 'inc/menubar.php';
        include 'inc/mobile-menu.php'; 
    ?>
<!-- Main Content -->
    <div id="main-content">
        <div class="page-title">
            <div class="page-title-wrapper" data-stellar-background-ratio="0.5">
                <div class="content container">
                    <h1 class="heading_primary">Gallery</h1>
                    <ul class="breadcrumbs">
                        <li class="item"><a href="index.html">Home</a></li>
                        <li class="item"><span class="separator"></span></li>
                        <li class="item active">Gallery</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="site-content">
            <div class="page-content">
               <div class="container">
                   <div class="sc-gallery">
                       <ul class="filter-controls">
                           <li><a href="javascript:;" class="filter active">All</a></li>
                           <li><a href="javascript:;" class="filter" data-filter=".filter-room">Room</a></li>
                           <li><a href="javascript:;" class="filter" data-filter=".filter-restaurant">Restaurant</a></li>
                           <li><a href="javascript:;" class="filter" data-filter=".filter-swimming">Swimming pool</a></li>
                           <li><a href="javascript:;" class="filter" data-filter=".filter-spa">Event</a></li>
                       </ul>
                       <div class="wrapper-gallery row" itemscope itemtype="http://schema.org/ItemList">
                           <div class="col-sm-6 filter-room filter-spa">
                               <div class="item">
                                   <a href="images/gallery/img-1.jpg" class="gallery-popup">
                                       <img src="images/gallery/img-1.jpg" alt=""></a>
                                   <div class="content">
                                       <h3>Hotel Restaurant</h3>
                                       <p>Lorem ipsum dolor sit amet</p>
                                   </div>
                               </div>
                           </div>

                           <div class="col-sm-6 filter-restaurant filter-swimming">
                               <div class="item">
                                   <a href="images/gallery/img-3.jpg" class="gallery-popup">
                                       <img src="images/gallery/img-3.jpg" alt=""></a>
                                   <div class="content">
                                       <h3>Hotel Restaurant</h3>
                                       <p>Lorem ipsum dolor sit amet</p>
                                   </div>
                               </div>
                           </div>
                           <div class="col-sm-6 filter-swimming filter-restaurant filter-room">
                               <div class="item">
                                   <a href="images/gallery/img-4.jpg" class="gallery-popup">
                                       <img src="images/gallery/img-4.jpg" alt=""></a>
                                   <div class="content">
                                       <h3>Hotel Restaurant</h3>
                                       <p>Lorem ipsum dolor sit amet</p>
                                   </div>
                               </div>
                           </div>
                           <div class="col-sm-6 filter-room filter-spa filter-restaurant">
                               <div class="item">
                                   <a href="images/gallery/img-5.jpg" class="gallery-popup">
                                       <img src="images/gallery/img-5.jpg" alt=""></a>
                                   <div class="content">
                                       <h3>Hotel Restaurant</h3>
                                       <p>Lorem ipsum dolor sit amet</p>
                                   </div>
                               </div>
                           </div>
                           <div class="col-sm-6 filter-spa filter-room filter-swimming">
                               <div class="item">
                                   <a href="images/gallery/img-6.jpg" class="gallery-popup">
                                       <img src="images/gallery/img-6.jpg" alt=""></a>
                                   <div class="content">
                                       <h3>Hotel Restaurant</h3>
                                       <p>Lorem ipsum dolor sit amet</p>
                                   </div>
                               </div>
                           </div>
                           <div class="col-sm-6 filter-swimming filter-restaurant filter-spa">
                               <div class="item">
                                   <a href="images/gallery/img-8.jpg" class="gallery-popup">
                                       <img src="images/gallery/img-8.jpg" alt=""></a>
                                   <div class="content">
                                       <h3>Hotel Restaurant</h3>
                                       <p>Lorem ipsum dolor sit amet</p>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php include 'inc/footer.php'; ?>