<!-- Mobile menu -->
    <nav class="visible-xs mobile-menu-container mobile-effect" itemscope itemtype="http://schema.org/SiteNavigationElement">
        <div class="inner-off-canvas">
            <div class="menu-mobile-effect navbar-toggle">Close <i class="fa fa-times"></i></div>
            <ul class="nav main-menu">
                <li class="menu-item"><a href="index.php">Home</a></li>
                <li class="menu-item"><a href="about.php">About</a></li>
                <li class="menu-item has-children">
                    <a href="rooms.php">Rooms</a>
                    <ul class="sub-menu">
                        <li class="menu-item"><a href="single.php">A/C Single Deluxe</a></li>
                        <li class="menu-item"><a href="double.php">A/C Double Deluxe</a></li>
                        <li class="menu-item"><a href="deluxe.php">A/C Deluxe Suite</a></li>
                        <li class="menu-item"><a href="family.php">A/C Eque Family Suite</a></li>
                        <li class="menu-item"><a href="officer.php">Juniour Officer's Room</a></li>
                    </ul>
                </li>
                <li class="menu-item has"><a href="gallery.php">Gallery</a></li>
                <!--
                <li class="menu-item has-children">
                    <a href="blog.php">Blog</a>
                    <ul class="sub-menu">
                        <li class="menu-item"><a href="blog-sidebar-left.php">Blog Sidebar Left</a></li>
                        <li class="menu-item"><a href="blog-sidebar-right.php">Blog Sidebar Right</a></li>
                        <li class="menu-item"><a href="blog-no-sidebar.php">Blog Without Sidebar</a></li>
                        <li class="menu-item"><a href="blog-single.php">Single Post</a></li>
                        <li class="menu-item"><a href="blog-single-gallery.php">Single Post Gallery</a></li>
                    </ul>
                </li>
                -->
                <li class="menu-item"><a href="package.php">Packages</a></li>
                <li class="menu-item"><a href="events.php">Events</a></li>   
                <li class="menu-item"><a href="contact.php">Contact</a></li>
            </ul>
        </div>
    </nav>
    <!-- nav.mobile-menu-container -->