<?php 

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, DELETE, PUT');

$method = $_SERVER['REQUEST_METHOD'];
// echo $method;
$method_url = $_SERVER['REQUEST_URL'];
echo $method_url;

$url = trim($method_url, '/');
$url = filter_var($url, FILTER_SANITIZE_URL);
$url = explode('/', $url);

// $table = [posts];




 ?>