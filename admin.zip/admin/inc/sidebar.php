<div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <li <?php if ($newtitle == "Hotel Management") {echo 'class="active"';} ?> >
                            <a class="active" href="dashbord.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
						<li class="submenu">
							<a href="#"><i class="fa fa-suitcase" aria-hidden="true"></i><span> Booking</span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
                                <li><a <?php if ($newtitle == "Booking List") {echo 'class="active"';} ?> href="booking_all.php">All Booking</a></li>
								<li><a <?php if ($newtitle == "Edit Booking") {echo 'class="active"';} ?> href="booking_edit.php">Edit Booking</a></li>
								<li><a <?php if ($newtitle == "Add Booking") {echo 'class="active"';} ?> href="booking_add.php">Add Booking</a></li>
							</ul>
						</li>
						<li class="submenu">
							<a href="#"><i class="fa fa-users" aria-hidden="true"></i> <span> Customers </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a <?php if ($newtitle == "Customers List") {echo 'class="active"';} ?> href="customers_list.php">All customers</a></li>
								<li><a <?php if ($newtitle == "Edit Customers") {echo 'class="active"';} ?> href="customers_edit.php">Edit Customer</a></li>
								<li><a <?php if ($newtitle == "Add Customers") {echo 'class="active"';} ?> href="customers_add.php">Add Customer</a></li>
							</ul>
						</li>
						<li class="submenu">
							<a href="#"><i class="fa fa-key" aria-hidden="true"></i> <span> Rooms </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a <?php if ($newtitle == "Rooms List") {echo 'class="active"';} ?> href="rooms_list.php">All Rooms</a></li>
								<li><a <?php if ($newtitle == "Edit Room") {echo 'class="active"';} ?> href="room_edit.php">Edit Room</a></li>
								<li><a <?php if ($newtitle == "Add Room") {echo 'class="active"';} ?> href="room_add.php">Add Room</a></li>
							</ul>
						</li>
                        <li class="submenu">
							<a href="#"><i class="fa fa-user"></i> <span> Staff </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a <?php if ($newtitle == "Staff List") {echo 'class="active"';} ?> href="staff_list.php">All Staff</a></li>
								<li><a <?php if ($newtitle == "Edit Staff") {echo 'class="active"';} ?> href="staff_edit.php">Edit Staff</a></li>
								<li><a <?php if ($newtitle == "Add Staff") {echo 'class="active"';} ?> href="staff_add.php">Add staff</a></li>
							</ul>
						</li>
                        <li <?php if ($newtitle == "Princing") {echo 'class="active"';} ?> >
                            <a href="pricing.php"><i class="fa fa-money" aria-hidden="true"></i> <span>Pricing</span></a>
                        </li>
						<li class="submenu">
							<a href="#"><i class="fa fa-share-alt" aria-hidden="true"></i> <span> Apps </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
							    <li>
								    <a <?php if ($newtitle == "Chat") {echo 'class="active"';} ?> href="chat.php"><i class="fa fa-comments"></i> <span>Chat</span> <span class="badge badge-pill text-white bg-primary float-right">5</span></a>
								</li>
							</ul>
						</li>
						<li class="submenu">
							<a href="#"><i class="fa fa-user"></i> <span> Employees </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a <?php if ($newtitle == "Employees List") {echo 'class="active"';} ?> href="Employees List.php">Employees List</a></li>
							</ul>
						</li>
						<li class="submenu">
							<a href="#"><i class="fa fa-money"></i> <span> Accounts </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a <?php if ($newtitle == "Invoices") {echo 'class="active"';} ?> href="invoices.php">Invoices</a></li>
								<li><a <?php if ($newtitle == "Payments") {echo 'class="active"';} ?> href="payments.php">Payments</a></li>
								<li><a <?php if ($newtitle == "Expenses") {echo 'class="active"';} ?> href="expenses.php">Expenses</a></li>
								<li><a <?php if ($newtitle == "Taxes") {echo 'class="active"';} ?> href="taxes.php">Taxes</a></li>
								<li><a <?php if ($newtitle == "Provident Fund") {echo 'class="active"';} ?> href="provident_fund.php">Provident Fund</a></li>
							</ul>
						</li>
						<li class="submenu">
							<a href="#"><i class="fa fa-book"></i> <span> Payroll </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a <?php if ($newtitle == "Salary") {echo 'class="active"';} ?> href="salary.php"> Employee Salary </a></li>
								<li><a <?php if ($newtitle == "Payslip") {echo 'class="active"';} ?> href="salary_view.php"> Payslip </a></li>
							</ul>
						</li>
                        <li <?php if ($newtitle == "Calendar") {echo 'class="active"';} ?> >
                            <a href="calendar.php"><i class="fa fa-calendar"></i> <span>Calendar</span></a>
                        </li>
                        <li class="submenu">
                            <a href="#"><i class="fa fa-commenting-o"></i> <span> Blog</span> <span class="menu-arrow"></span></a>
                            <ul style="display: none;">
                                <li><a <?php if ($newtitle == "Blog") {echo 'class="active"';} ?> href="blog.php">Blog</a></li>
                                <li><a <?php if ($newtitle == "Blog View") {echo 'class="active"';} ?> href="blog_details.php">Blog View</a></li>
                                <li><a <?php if ($newtitle == "Add Blog") {echo 'class="active"';} ?> href="blog_add.php">Add Blog</a></li>
                                <li><a <?php if ($newtitle == "Edit Blog") {echo 'class="active"';} ?> href="blog_add.php">Edit Blog</a></li>
                            </ul>
                        </li>
						<li>
							<a href="assets.html"><i class="fa fa-cube"></i> <span>Assets</span></a>
						</li>
						<li>
							<a href="activities.html"><i class="fa fa-bell-o"></i> <span>Activities</span></a>
						</li>
						<li class="submenu">
							<a href="#"><i class="fa fa-flag-o"></i> <span> Reports </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a <?php if ($newtitle == "Expense Report") {echo 'class="active"';} ?> href="expense-reports.php"> Expense Report </a></li>
								<li><a <?php if ($newtitle == "Invoice Report") {echo 'class="active"';} ?> href="invoice-reports.php"> Invoice Report </a></li>
							</ul>
						</li>
                        <li>
                            <a href="settings.php"><i class="fa fa-cog"></i> <span>Settings</span></a>
                        </li>
                        <li class="menu-title">UI Elements</li>
                        <li class="submenu">
                            <a href="#"><i class="fa fa-laptop"></i> <span> Components</span> <span class="menu-arrow"></span></a>
                            <ul style="display: none;">
                                <li><a href="uikit.html">UI Kit</a></li>
                                <li><a href="typography.html">Typography</a></li>
                                <li><a href="tabs.html">Tabs</a></li>
                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="#"><i class="fa fa-edit"></i> <span> Forms</span> <span class="menu-arrow"></span></a>
                            <ul style="display: none;">
                                <li><a href="form-basic-inputs.html">Basic Inputs</a></li>
                                <li><a href="form-input-groups.html">Input Groups</a></li>
                                <li><a href="form-horizontal.html">Horizontal Form</a></li>
                                <li><a href="form-vertical.html">Vertical Form</a></li>
                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="#"><i class="fa fa-table"></i> <span> Tables</span> <span class="menu-arrow"></span></a>
                            <ul style="display: none;">
                                <li><a href="tables-basic.html">Basic Tables</a></li>
                                <li><a href="tables-datatables.html">Data Table</a></li>
                            </ul>
                        </li>
                        
                        <li class="menu-title">Extras</li>
                        <li class="submenu">
                            <a href="#"><i class="fa fa-columns"></i> <span>Pages</span> <span class="menu-arrow"></span></a>
                            <ul style="display: none;">
                                <li><a href="login.html"> Login </a></li>
                                <li><a href="register.html"> Register </a></li>
                                <li><a href="forgot-password.html"> Forgot Password </a></li>
                                <li><a href="change-password2.html"> Change Password </a></li>
                                <li><a href="lock-screen.html"> Lock Screen </a></li>
                                <li><a href="profile.html"> Profile </a></li>
                                <li><a href="gallery.html"> Gallery </a></li>
                                <li><a href="error-404.html">404 Error </a></li>
                                <li><a href="error-500.html">500 Error </a></li>
                                <li><a href="blank-page.html"> Blank Page </a></li>
                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="javascript:void(0);"><i class="fa fa-share-alt"></i> <span>Multi Level</span> <span class="menu-arrow"></span></a>
                            <ul style="display: none;">
                                <li class="submenu">
                                    <a href="javascript:void(0);"><span>Level 1</span> <span class="menu-arrow"></span></a>
                                    <ul style="display: none;">
                                        <li><a href="javascript:void(0);"><span>Level 2</span></a></li>
                                        <li class="submenu">
                                            <a href="javascript:void(0);"> <span> Level 2</span> <span class="menu-arrow"></span></a>
                                            <ul style="display: none;">
                                                <li><a href="javascript:void(0);">Level 3</a></li>
                                                <li><a href="javascript:void(0);">Level 3</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="javascript:void(0);"><span>Level 2</span></a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0);"><span>Level 1</span></a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        