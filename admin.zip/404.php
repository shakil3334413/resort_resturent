    <?php 
        include 'inc/header.php';
        include 'inc/menubar.php';
        include 'inc/mobile-menu.php'; 
    ?>
    <!-- nav.mobile-menu-container -->

    <!-- Main Content -->
    <div id="main-content">
        <div class="page-title">
            <div class="page-title-wrapper" data-stellar-background-ratio="0.5">
                <div class="content container">
                    <h1 class="heading_primary">404 Page</h1>
                    <ul class="breadcrumbs">
                        <li class="item"><a href="index.html">Home</a></li>
                        <li class="item"><span class="separator"></span></li>
                        <li class="item active">404 Page</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="page-404 site-content container">
            <div class="page-content text-center">
                <h1>Page not found</h1>
                <p>Sorry, We couldn't find the page you're looking for.
                  <br>  Try returning to the <a href="index.html">HomePage</a>.</p>
                <img src="images/page/404_img.jpg" alt="">
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php include 'inc/footer.php'; ?>