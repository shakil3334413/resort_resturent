$(".thim-countdown .count-down").mbComingsoon({
        expiryDate: new Date($(".thim-countdown").data('date')),
        speed     : 100
    });