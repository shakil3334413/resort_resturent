// Initialize and add the map
    function sc_Map() {
        // The location of London
        var manutd = {
            lat: -37.8040982,
            lng: 144.9570935
        };
        // The map, centered at London
        var map = new google.maps.Map(
            document.getElementById('google-map'), {zoom: 12, center: manutd});
        // The marker, positioned at London
        var marker = new google.maps.Marker({position: manutd, map: map});
    }